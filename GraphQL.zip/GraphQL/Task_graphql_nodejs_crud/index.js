//install necessary package
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import express from "express";
import pkg from "body-parser";
import { resolvers } from "./src/schema/resolvers/personResolver.mjs";
import { loadFilesSync } from "@graphql-tools/load-files";
import { mergeTypeDefs, mergeResolvers } from "@graphql-tools/merge";



const { json } = pkg;
const port = 3000;
const app = express();

const mergedTypeDefs = mergeTypeDefs(
  loadFilesSync(
    "C:\\XX1489_Rohith D_PD-Full Stack Development\\Full Stack Development\\GraphQL\\Task_graphql_nodejs_crud\\src\\schema\\typedef"
  )
);
const mergedResolvers = mergeResolvers([resolvers]);

async function appserver() {
  const server = new ApolloServer({
    typeDefs: mergedTypeDefs,
    resolvers: mergedResolvers
    
  });
  await server.start();
  // app.use(verifyjwt);
  app.use("/graphql",json(),expressMiddleware(server));
  
}
appserver();

app.listen(port, () => {
  console.log(`👏 Port is listenting on http://localhost:${port}/graphql`);
});

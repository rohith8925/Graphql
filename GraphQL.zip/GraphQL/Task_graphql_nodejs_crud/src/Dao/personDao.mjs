import { connection } from "../dbconnection/connection.js";

//login
export async function loginPersons(args) {
  try {
    const sql = `select * from xx1489_persons where person_id=:person_id and first_name=:first_name`;
    const bindParams = {
      person_id: args.INPUT_PAYLOAD.person_id,
      first_name: args.INPUT_PAYLOAD.first_name
    };
    const options = { autoCommit: true };
    const result = await connection.execute(sql, bindParams, options);
    console.log(result);
    // connection.close();
    return  { message: "✅ Login Successfully" };
  } catch (error) {
    console.error("😒Error fetching data:", error);
    throw error;
  }
}

//read
export async function readPerson() {
  try {
    // const connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute(
      `SELECT person_id, first_name, last_name FROM xx1489_persons`
    );
    console.log(result.rows);
    return result.rows;
  } catch (error) {
    console.error("😒Error fetching data:", error);
    throw error;
  }
}

//Insert
export async function insertPersons(args) {
  try {
    const sql = `insert into xx1489_persons values(:person_id,:first_name,:last_name)`;
    const bindParams = {
      person_id: args.INPUT_PAYLOAD.person_id,
      first_name: args.INPUT_PAYLOAD.first_name,
      last_name: args.INPUT_PAYLOAD.last_name,
    };
    const options = { autoCommit: true };
    const result = await connection.execute(sql, bindParams, options);
    console.log(result);
    // connection.close();
    return { message: "✅ Record inserted successfully" };
  } catch (error) {
    console.error("😒Error fetching data:", error);
    throw error;
  }
}

//Update

export async function updatePersons(args) {
  try {
    // const connection = await oracledb.getConnection(dbConfig);
    const sql = `update xx1489_persons set last_name=:last_name where person_id=:person_id`;
    const bindParams = {
      person_id: args.INPUT_PAYLOAD.person_id,
      last_name: args.INPUT_PAYLOAD.last_name,
    };
    const options = { autoCommit: true };
    const result = await connection.execute(sql, bindParams, options);
    console.log(result);
    // connection.close();
    return { message: "✅ Updated records successfully" };
  } catch (error) {
    console.error("😒Error fetching data:", error);
    throw error;
  }
}

//delete

export async function deletePersons(args) {
  try {
    const sql = `delete from xx1489_persons where person_id=:person_id`;
    const bindParams = { person_id: args.INPUT_PAYLOAD.person_id };
    const options = { autoCommit: true };
    const result = await connection.execute(sql, bindParams, options);
    console.log(result);
    // connection.close();
    return { message: "🚫 Deleted records successfully" };
  } catch (error) {
    console.error("😒Error fetching data:", error);
    throw error;
  }
}

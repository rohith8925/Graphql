// const jwt  = require('jsonwebtoken')
import jwt from 'jsonwebtoken'
// const config = require('../../config/default')

export function verifyjwt(req,res,next){
    // console.log('----------req-------',req)
    const token = req.headers['authorization']
    // console.log(token)
    // if(!token) 
    // return res.status(401).json('Unauthorize user')

   try{
        const decoded = jwt.verify(token,process.env.TOKEN_KEY);
        console.log(decoded)
        req.user = decoded
        next()

   }catch(e){
    res.status(400).json('Token not valid')
   }
}


import {
  loginPersonService,
  readService,
  insertService,
  updateService,
  deleteService,
} from "../../service/personService.mjs";


//loginperson
async function loginPersons(_,args)
{
    const resolverPersonService = await loginPersonService(args);
    return resolverPersonService;
}

// read
async function allPersons() {
  const resolverService = await readService();
  return resolverService;
}

//insert

async function insertPersons(_, args) {
  const resolverInsertService = await insertService(args);
  return resolverInsertService;
}

//update

async function updatePersons(_, args) {
  const resolverUpdateService = await updateService(args);
  return resolverUpdateService;
}

//delete
async function deletePersons(_, args) {
  const resolverDeleteService = await deleteService(args);
  return resolverDeleteService;
}

export const resolvers = {
  Query: {
    allPersons
  },
  Mutation: {
    loginPersons,
    insertPersons,
    updatePersons,
    deletePersons,
  },
};

// export default resolvers

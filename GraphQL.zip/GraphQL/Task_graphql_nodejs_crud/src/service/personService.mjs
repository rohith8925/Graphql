import {
  loginPersons,
  deletePersons,
  insertPersons,
  readPerson,
  updatePersons,
} from "../Dao/personDao.mjs";

//loginPerson
export async function loginPersonService(args){
  const resolverPersonLogin = await loginPersons(args);
  return resolverPersonLogin;
}
//Read
export async function readService() {
  const resolverPerson = await readPerson();
  return resolverPerson;
}

//insert

export async function insertService(args) {
  const insertresolverPerson = await insertPersons(args);
  return insertresolverPerson;
}

//update

export async function updateService(args) {
  const updateresolverPerson = await updatePersons(args);
  return updateresolverPerson;
}

//delete

export async function deleteService(args) {
  const deleteresolverPerson = await deletePersons(args);
  return deleteresolverPerson;
}

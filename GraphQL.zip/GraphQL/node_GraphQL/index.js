import { ApolloServer } from "@apollo/server";
import {expressMiddleware} from '@apollo/server/express4'
import express from 'express'

import pkg from 'body-parser'

const{ json } = pkg

const port = 7000;
const app = express();

(async()=>
{
    const typeDefs = `

        type createPerson{
            message : String
        }

      type Person
      {
        person_id :Int
        first_name : String
        last_name : String
      }
      input Persons
      {
        person_id :Int,
        first_name:String,
        last_name:String
      }

      type Query {
        allPersons : [Person]
      }
      type Mutation
      {
        createPerson(person_id:Int,first_name:String,last_name:String):createPerson
        createPersons(INPUT_PAYLOAD:Persons):createPerson

      }
    `;
 
    const resolvers = {
        Query:
        {
            async allPersons(root,args)
            {
                console.log('-----------root------',root)
                return[{person_id : 1,first_name : "Rohith",last_name : "D"}];
            },
        },
        Mutation:{
            async createPerson(root,args)
            {
                console.log('----------args------',args)
                return{message : "Person created successfully!!"}
            },
            async createPersons(root,args)
            {
                console.log('----------args------',args)
                return{message : "Person created successfully!!"}
            }

        }
    }

    const server = new ApolloServer({
        typeDefs,
        resolvers
    });
    await server.start();
    app.use('/graphql',json(),expressMiddleware(server))
})();

app.listen(port,()=>
{
    console.log(`Port is listenting on http://localhost:${port}/graphql`)
})


